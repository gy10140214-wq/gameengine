using UnityEngine;

public class Enemy : MonoBehaviour
{
    public float health = 100f;

    public void TakeDamage(float amount)
    {
        health -= amount;
        Debug.Log($"{gameObject.name} damaged! Remaining HP: {health}");

        if (health <= 0f)
        {
            Die();
        }
    }

    void Die()
    {
        // �״� ���� �Ǵ� ����Ʈ ����
        Destroy(gameObject);
    }
}
